/* 
   NSBitmapImageRep.h

   Bitmap image representations

   Copyright (C) 1996 Free Software Foundation, Inc.

   Written by:  Adam Fedor <fedor@colorado.edu>
   Date: Feb 1996
   
   This file is part of the GNUstep GUI Library.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this library; see the file COPYING.LIB.
   If not, write to the Free Software Foundation,
   51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.
*/ 

#ifndef _GNUstep_H_NSBitmapImageRep
#define _GNUstep_H_NSBitmapImageRep
#import <GNUstepBase/GSVersionMacros.h>

#include <AppKit/NSImageRep.h>
#include <Foundation/NSDictionary.h>

@class NSArray;
@class NSString;
@class NSData;
@class NSMutableData;
@class NSColor;

/** Describes the type of compression used on an image.  Possible compressions:
  <list>
   <item> NSTIFFCompressionNone; </item>
   <item> NSTIFFCompressionCCITTFAX3; </item>
   <item> NSTIFFCompressionCCITFAX4; </item>
   <item> NSTIFFCompressionLZW; </item>
   <item> NSTIFFCompressionOldJPEG; </item>
   <item> NSTIFFCompressionJPEG; </item>
   <item> NSTIFFCompressionNEXT; </item>
   <item> NSTIFFCompressionPackBits. </item>
  </list>
 */
typedef enum _NSTIFFCompression {
  NSTIFFCompressionNone  = 1,
  NSTIFFCompressionCCITTFAX3,
  NSTIFFCompressionCCITTFAX4,
  NSTIFFCompressionLZW,
  NSTIFFCompressionOldJPEG,
  NSTIFFCompressionJPEG,
  NSTIFFCompressionNEXT,
  NSTIFFCompressionPackBits
} NSTIFFCompression;

#if OS_API_VERSION(GS_API_MACOSX, GS_API_LATEST)
/** Type of image
  <list>
   <item> NSTIFFFileType; </item>
   <item> NSBMPFileType; Not implemented </item>
   <item> NSGIFFileType; </item>
   <item> NSJPEGFileType; </item>
   <item> NSPNGFileType; </item>
   <item> NSJPEG2000FileType. Not implemented </item>
  </list>
 */
typedef enum _NSBitmapImageFileType {
    NSTIFFFileType = 0,
    NSBMPFileType = 1,
    NSGIFFileType = 2,
    NSJPEGFileType = 3,
    NSPNGFileType = 4,
    NSJPEG2000FileType = 5  // available in Mac OS X v10.4
} NSBitmapImageFileType;

APPKIT_EXPORT NSString *NSImageCompressionMethod;  // NSNumber; only for TIFF files
APPKIT_EXPORT NSString *NSImageCompressionFactor;  // NSNumber 0.0 to 255.0; only for JPEG files (GNUstep extension: JPEG-compressed TIFFs too)
APPKIT_EXPORT NSString *NSImageDitherTranparency;  // NSNumber boolean; only for writing GIF files
APPKIT_EXPORT NSString *NSImageRGBColorTable;  // NSData; only for reading & writing GIF files
APPKIT_EXPORT NSString *NSImageInterlaced;  // NSNumber boolean; only for writing PNG files
//APPKIT_EXPORT NSString *NSImageColorSyncProfileData; // Mac OX X only
//APPKIT_EXPORT NSString *GSImageICCProfileData;  // if & when color management comes to GNUstep
APPKIT_EXPORT NSString *NSImageFrameCount;  // NSNumber integer; only for reading animated GIF files
APPKIT_EXPORT NSString *NSImageCurrentFrame; // NSNumber integer; only for animated GIF files
APPKIT_EXPORT NSString *NSImageCurrentFrameDuration;  // NSNumber float; only for reading animated GIF files
APPKIT_EXPORT NSString *NSImageLoopCount; // NSNumber integer; only for reading animated GIF files
APPKIT_EXPORT NSString *NSImageGamma; // NSNumber 0.0 to 1.0; only for reading & writing PNG files
APPKIT_EXPORT NSString *NSImageProgressive; // NSNumber boolean; only for reading & writing JPEG files
//APPKIT_EXPORT NSString *NSImageEXIFData; // No GNUstep support yet; for reading & writing JPEG

#endif

@interface NSBitmapImageRep : NSImageRep
{
  // Attributes
  unsigned int		_bytesPerRow;
  unsigned int		_numColors;
  unsigned int		_bitsPerPixel;   
  unsigned short  	_compression;
  float			_comp_factor;
  NSMutableDictionary   *_properties;
  BOOL			_isPlanar;
  unsigned char		**_imagePlanes;
  NSMutableData		*_imageData;
}

//
// Allocating and Initializing a New NSBitmapImageRep Object 
//
+ (id) imageRepWithData: (NSData*)imageData;
+ (NSArray*) imageRepsWithData: (NSData*)imageData;
- (id) initWithData: (NSData*)imageData;
- (id) initWithFocusedViewRect: (NSRect)rect;
- (id) initWithBitmapDataPlanes: (unsigned char**)planes
		     pixelsWide: (int)width
		     pixelsHigh: (int)height
		  bitsPerSample: (int)bps
		samplesPerPixel: (int)spp
		       hasAlpha: (BOOL)alpha
		       isPlanar: (BOOL)isPlanar
		 colorSpaceName: (NSString*)colorSpaceName
		    bytesPerRow: (int)rowBytes
		   bitsPerPixel: (int)pixelBits;

#if OS_API_VERSION(GS_API_MACOSX, GS_API_LATEST)
- (void)colorizeByMappingGray:(float)midPoint 
		      toColor:(NSColor *)midPointColor 
		 blackMapping:(NSColor *)shadowColor
		 whiteMapping:(NSColor *)lightColor;
- (id)initWithBitmapHandle:(void *)bitmap;
- (id)initWithIconHandle:(void *)icon;
#endif

//
// Getting Information about the Image 
//
- (int) bitsPerPixel;
- (int) samplesPerPixel;
- (BOOL) isPlanar;
- (int) numberOfPlanes;
- (int) bytesPerPlane;
- (int) bytesPerRow;

//
// Getting Image Data 
//
- (unsigned char*) bitmapData;
- (void) getBitmapDataPlanes: (unsigned char**)data;

//
// Producing a TIFF Representation of the Image 
//
+ (NSData*) TIFFRepresentationOfImageRepsInArray: (NSArray*)anArray;
+ (NSData*) TIFFRepresentationOfImageRepsInArray: (NSArray*)anArray
				usingCompression: (NSTIFFCompression)type
					  factor: (float)factor;
- (NSData*) TIFFRepresentation;
- (NSData*) TIFFRepresentationUsingCompression: (NSTIFFCompression)type
					factor: (float)factor;

#if OS_API_VERSION(GS_API_MACOSX, GS_API_LATEST)
+ (NSData *)representationOfImageRepsInArray:(NSArray *)imageReps 
				   usingType:(NSBitmapImageFileType)storageType
				  properties:(NSDictionary *)properties;
- (NSData *)representationUsingType:(NSBitmapImageFileType)storageType 
			 properties:(NSDictionary *)properties;
#endif

//
// Setting and Checking Compression Types 
//
+ (void) getTIFFCompressionTypes: (const NSTIFFCompression**)list
			   count: (int*)numTypes;
+ (NSString*) localizedNameForTIFFCompressionType: (NSTIFFCompression)type;
- (BOOL) canBeCompressedUsing: (NSTIFFCompression)compression;
- (void) getCompression: (NSTIFFCompression*)compression
		 factor: (float*)factor;
- (void) setCompression: (NSTIFFCompression)compression
		 factor: (float)factor;

#if OS_API_VERSION(GS_API_MACOSX, GS_API_LATEST)
- (void)setProperty:(NSString *)property withValue:(id)value;
- (id)valueForProperty:(NSString *)property;
#endif

@end

@interface NSBitmapImageRep (GNUstepExtension)
+ (NSArray*) imageRepsWithFile: (NSString *)filename;
@end

#endif // _GNUstep_H_NSBitmapImageRep
